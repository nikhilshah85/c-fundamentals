﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conditionsDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Welcome to .Net Programming");
            #region Login
            //bool tryLogin = true;
            //int attempts = 0;

            //while (tryLogin)
            //{
            //    Console.Clear();
            //    Console.WriteLine("Enter User Name");
            //    string uName = Console.ReadLine();

            //    Console.WriteLine("Enter Password");
            //    string pwd = Console.ReadLine();

            //    if (uName == "Nikhil" && pwd == "nikhil@1234")
            //    {
            //        Console.WriteLine("Welcome " + uName);
            //        tryLogin = false;
            //    }
            //    else
            //    {
            //        Console.WriteLine("Incorrect Credentials");
            //        attempts++;
            //        if (attempts == 3)
            //        {
            //            Console.WriteLine("Account is Locked after 3 Failed attempts, please contact admin");
            //            tryLogin = false;
            //        }
            //    }

            //}
            #endregion

            #region If Condition and While loop
            //bool continueProgram = true;

            //while (continueProgram == true)
            //{
            //    Console.Clear();

            //    Console.WriteLine("Please Enter Your Fav Number ENTER 0 if you do not have a fav Number");

            //    int favNumber = Convert.ToInt32(Console.ReadLine());

            //    if (favNumber < 0)
            //    {
            //        Console.WriteLine("This is a Negative Number");
            //    }
            //    else if (favNumber > 0 && favNumber < 25)
            //    {
            //        Console.WriteLine("This is a Good Number");
            //    }
            //    else if (favNumber > 25 && favNumber < 50)
            //    {
            //        Console.WriteLine("Very Good Number");
            //    }
            //    else if (favNumber > 50 && favNumber < 75)
            //    {
            //        Console.WriteLine("This is an Excellent Number");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Number is out of out Reach, this is more than excellent");
            //    }
            //    if (favNumber == 0)
            //    {
            //        continueProgram = false;
            //        Console.WriteLine(" Thank you ");
            //    }
            //    Console.ReadLine();

            //}
            #endregion

            #region Switch Case -  Banking Menu
            //bool showMenu = true;
            //int choice = 0;
            //while (showMenu)
            //{
            //    Console.ReadLine();
            //    Console.Clear();
            //    Console.WriteLine("-----~~~~~~~~~~~~~~~!! Welcome to Banking !!~~~~~~~~~~~~~~~~~~~~~~~--------------");
            //    Console.WriteLine("1. Create New Account");
            //    Console.WriteLine("2. Widraw");
            //    Console.WriteLine("3. Deposit");
            //    Console.WriteLine("4. Transfer");
            //    Console.WriteLine("5. View Account Details");
            //    Console.WriteLine("6. Exit");
            //    choice = Convert.ToInt32(Console.ReadLine());
            //    switch (choice)
            //    {                   
            //        case 1:
            //            //20 lines of code here
            //            Console.WriteLine("Account opening successful");
            //            break;
            //        case 2:
            //            Console.WriteLine("Widraw Process started");
            //            break;
            //        case 3:
            //            Console.WriteLine("Deposit Process started");
            //            break;
            //        case 4:
            //            Console.WriteLine("Transfer Successful ");
            //            break;
            //        case 5:
            //            Console.WriteLine("Below are you account Details");
            //            Console.WriteLine("Acc no : 101 ");
            //            Console.WriteLine("Acc Name : Karan ");
            //            Console.WriteLine("Acc Balance : 25000 ");
            //            break;
            //        case 6:
            //            Console.WriteLine("Thank you For Banking With us");
            //            showMenu = false;
            //            break;                        
            //        default:
            //            Console.WriteLine("Sorry that was not a valid option");
            //            break;
            //    }
            //}
            #endregion


            //collections in .net 
            //Non-generic  Array, ArrayList, HashTable
            //Generic -  List, Dictionry

            #region Static Array
            //string product = "Iphone"; // will store only 1 value
            //product = "Mac Book"; //this will over ride the first one

            //string[] products  = new string[5];
            //products[0] = "Iphone";
            //products[1] = "Mac Book";
            //products[2] = "Fossil";
            //products[3] = "Pepsi";
            //products[4] = "Maggie Noodles";

            ////Console.WriteLine(products[3]);
            //for (int i = 0; i < products.Length; i++)
            //{
            //    Console.WriteLine(products[i]);
            //}
            #endregion

            #region Dynamic Array

            //Console.WriteLine("How Many Products You have ?");
            //int count = Convert.ToInt32(Console.ReadLine());

            //string[] products = new string[count];

            //for (int i = 0; i < products.Length; i++)
            //{
            //    Console.WriteLine("Enter Product No " + (i+1));
            //    products[i] = Console.ReadLine();
            //}
            //Console.ReadLine();
            //Console.Clear();

            //for (int i = 0; i < products.Length; i++)
            //{
            //    Console.WriteLine(products[i]);
            //}
            #endregion

            Console.WriteLine("Enter Number");
            int totalNumbers = Convert.ToInt32(Console.ReadLine());

            int[] numbers =new int[totalNumbers];

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine("Enter Number  " + (i+1));
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("Thank you For the numbers, below is the quick summary");
            int evenNumbers = 0;
            int oddNumbers = 0;
            int sumOfNumbers = 0;
            int negativeNumber = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] % 2 == 0)
                {
                    evenNumbers++;
                }
                else
                {
                    oddNumbers++;
                }
                if (numbers[i] < 0)
                {
                    negativeNumber++;
                }
                sumOfNumbers = sumOfNumbers + numbers[i];
            }

            Console.WriteLine("Even Numbers : "  + evenNumbers);
            Console.WriteLine("Odd Numbers : " + oddNumbers);
            Console.WriteLine("Negative Numbers : " + negativeNumber);
            Console.WriteLine("Sum of  Numbers : " + sumOfNumbers);

        }
    }
}
