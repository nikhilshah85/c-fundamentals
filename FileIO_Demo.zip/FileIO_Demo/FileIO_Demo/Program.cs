﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FileIO_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            #region Eg.1 Write to a file

            //Console.WriteLine("Please Enter your name");
            //string name = Console.ReadLine();
            //Console.WriteLine("Please Enter Your City");
            //string city  = Console.ReadLine();
            //Console.WriteLine("What is your designation");
            //string designation = Console.ReadLine();

            //FileStream fs = new FileStream(  name +".txt", FileMode.Create,FileAccess.Write);

            //StreamWriter sw = new StreamWriter(fs);
            //sw.WriteLine("Hello My Name is " + name);
            //sw.WriteLine("I am from : " + city);
            //sw.WriteLine("I work as : " + designation);

            //sw.Close();
            //fs.Close();
            #endregion


            #region  Eg.2 Read from the file
            //Console.WriteLine("Please Enter Your Name");
            //string name = Console.ReadLine();

            //if (File.Exists(name + ".txt"))
            //{
            //    FileStream fs = new FileStream(name + ".txt", FileMode.Open, FileAccess.Read);
            //    StreamReader sr = new StreamReader(fs);

            //    Console.WriteLine(sr.ReadToEnd());
            //    sr.Close();
            //    fs.Close();
            //}
            //else
            //{
            //    Console.WriteLine("Sorry Your Details are not found in system, do you wish to create ?");
            //}
            #endregion

            //Eg.3 With custom data type, Auto generate the account number

            Console.WriteLine("Please Enter Account Name");
          string name = Console.ReadLine();
            Console.WriteLine("PLease Enter Account Type");
           string type = Console.ReadLine();
            Console.WriteLine("Please Enter Initial Balance");
            double balance = Convert.ToDouble(Console.ReadLine());

            Accounts acc = new Accounts(name,type,balance);
          

            Console.WriteLine("Account Created Successfully, ");
            Console.WriteLine("New Account No is " + acc.accNo);


        }
    }
}
