﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FileIO_Demo
{
    internal class Accounts
    {
        public int accNo { get; set; }
        public string accName { get; set; }
        public string accType { get; set; }
        public double accBalance { get; set; }
        public bool accIsActive { get; set; }

        public Accounts(string name, string type, double balance)
        {
            if (File.Exists("autoaccNo.txt"))
            {
                FileStream readNumber = new FileStream("autoaccNo.txt",FileMode.Open,FileAccess.Read);
                StreamReader sr = new StreamReader(readNumber);
                int v_accNo =Convert.ToInt32(sr.ReadLine());
                sr.Close();
                readNumber.Close();

                v_accNo = v_accNo + 1;
                accNo = v_accNo;


                FileStream writeNumberBackToFile = new FileStream("autoaccNo.txt", FileMode.Create, FileAccess.Write);
                StreamWriter writer = new StreamWriter(writeNumberBackToFile);
                writer.Write(v_accNo);
                writer.Close();
                writeNumberBackToFile.Close();


                FileStream saveAccount = new FileStream(v_accNo + ".txt",FileMode.Create,FileAccess.Write);
                StreamWriter    wr = new StreamWriter(saveAccount);
                accIsActive = true;
                accName = name;
                accType = type;
                accBalance = balance;
                wr.WriteLine("Account Number " + accNo);
                wr.WriteLine("Account Name " + accName);
                wr.WriteLine("Account Type " + accType);
                wr.WriteLine("Account Balance " + accBalance);
                wr.WriteLine("Account Is Active " + accIsActive);
                wr.Close();
                saveAccount.Close();
            }
            else
            {
                FileStream newFile = new FileStream("autoaccNo.txt", FileMode.Create, FileAccess.Write);
                StreamWriter writer = new StreamWriter(newFile);
                writer.Write(500);
                writer.Close();
                newFile.Close();

                accNo = 500;
            }
        }


    }
}
