﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Accounts 
            //Accounts accObj = new Accounts();
            //accObj.accName = "Kiran";
            //accObj.accNo = 101;
            //accObj.accBalance = 5000;
            //accObj.accType = "Savings";

            //bool continueTransaction = true;

            //while (continueTransaction)
            //{
            //    Console.Clear();
            //    Console.WriteLine("---------- Welcome to AMT ---------------");
            //    Console.WriteLine("Available Balance : " + accObj.accBalance);

            //    Console.WriteLine("Choose From Option \n 1. Widraw \n 2. Deposit \n 3. Transfer \n 4. CheckBalance \n 5. Exit");

            //    int choice = Convert.ToInt32(Console.ReadLine());
            //    int amount = 0;

            //    switch (choice)
            //    {
            //        case 1:

            //            try
            //            {

            //                Console.WriteLine("Enter Amount to Widraw.");
            //                amount = Convert.ToInt32(Console.ReadLine());
            //                accObj.Widraw(amount);
            //                Console.WriteLine("Widrawal Successful, Balance after widrawal is :" + accObj.accBalance);
            //            }
            //            catch(Exception ex)
            //            {
            //                Console.WriteLine(ex.Message);
            //            }
            //            break;
            //        case 2:
            //            Console.WriteLine("Enter Amount to Deposit.");
            //            amount = Convert.ToInt32(Console.ReadLine());
            //            accObj.Deposit(amount);
            //            Console.WriteLine("Deposit Successful, Balance after Deposit is :" + accObj.accBalance);
            //            break;
            //        case 3:

            //            Console.WriteLine("From Which account you want to transfer");
            //            int fromAccountNo = Convert.ToInt32(Console.ReadLine());

            //            Console.WriteLine("Enter the account number to transfer funds");
            //            int toAccountNo = Convert.ToInt32(Console.ReadLine());

            //            Console.WriteLine("Enter Amount to Transfer.");
            //            amount = Convert.ToInt32(Console.ReadLine());

            //            accObj.Transfer(fromAccountNo, toAccountNo, amount);
            //            Console.WriteLine("Transfer Successful, Balance after transfer is :" + accObj.accBalance);
            //            break;
            //        case 4:
            //            Console.WriteLine(" Your Available Balance is : " + accObj.accBalance);
            //            break;
            //        case 5:
            //            continueTransaction = false;
            //            Console.WriteLine("Thank you for banking with us");
            //            break;
            //        default:
            //            break;
            //    }
            //    Console.WriteLine("Press Enter To Continue.");
            //    Console.ReadLine();
            //}
            #endregion

            Calculations cal = new Calculations();
            //  Console.WriteLine((cal.Add(60, 250, 1000,2000)));

            Console.WriteLine(cal.Add(10,20,30,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,5,5,5,5,5,5));
        }
    }
}
