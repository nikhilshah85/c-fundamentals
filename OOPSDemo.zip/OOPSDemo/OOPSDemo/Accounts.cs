﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSDemo
{
    internal class Accounts
    {
        public int accNo { get; set; }
        public string accName { get; set; }
        public string accType { get; set; }
        public double accBalance { get; set; }


        public double Widraw(int amount_to_widraw)
        {
            if (amount_to_widraw < 100 && amount_to_widraw >= 0)
            {
                throw new Exception("Please enter amount more than 100.");
            }
            if (amount_to_widraw < 0)
            {
                throw new Exception("You cannot widraw negative value");
            }
            if (amount_to_widraw > accBalance)
            {
                throw new Exception("Insufficient Balance");
            }
            if (amount_to_widraw > 25000)
            {
                throw new Exception("You cannot widraw more than 25000");
            }
            accBalance = accBalance - amount_to_widraw; 
            return accBalance;
        }

        public double Deposit(int amount_to_deposit)
        {
            accBalance = accBalance + amount_to_deposit;
            return accBalance;
        }


        public double Transfer(int from_accNo, int to_accNo,int transfer_amount)
        {
            //we are not transfering the amount right now, this is just a skeletionn, method will come back later
            //increase the accbalance of reciever account
            //decrease the accBalanc of sender account
            return accBalance;
        }


    }
}
