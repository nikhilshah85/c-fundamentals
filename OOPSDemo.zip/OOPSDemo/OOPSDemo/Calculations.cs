﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSDemo
{
    internal class Calculations
    {
        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        public string Add(string n1, string n2)
        {
            return n2 + n1;
        }
        public int Add(int num1, int num2, int num3)
        {
            return num1 + num2 + num3;
        }

        public int Add(int num1, int num2, int num3, int num4)
        {
            return num1 + num2 + num3 + num4;
        }

        public int Add(int num1, int num2, params int[] morenumber)
        {
            int temp = 0;
            for (int i = 0; i < morenumber.Length; i++)
            {
                temp = temp + morenumber[i];
            }
            return num1 + num2 + temp;
        }

    }
}
